# Leverage's Kitchen

Mobile-first landing page for Leverage's Kitchen, a small food business at Jui Junction, Hastings, Sierra Leone.

**Live site:** https://leveragekitchen.netlify.app

## What it shows
- Business name, tagline and services: dine-in, takeaway, delivery, catering and events
- Menu with prices in Leones (SLE)
- Opening and delivery hours
- Location with a landmark (Alpha Bar, fuel station, Jui Junction, opposite Kuma Building) and a Google Maps code
- Orange Money payment details
- WhatsApp and call buttons that stay on screen on phones

## Files
- `index.html`: the whole page, with inline CSS and no JavaScript or frameworks
- `logo.jpg`, `parfait.jpg`, `cakes.jpg`, `pizza-snacks.jpg`: compressed images

## Built for slow networks
- One HTML file, system fonts, no frameworks, no JavaScript
- Images are compressed and load lazily below the first screen
- Total page weight is well under 500 KB

## Accessibility
17px body text, strong colour contrast, descriptive alt text, large tap targets and a skip link.

## Write-up
Leverage's Kitchen serves customers around Jui Junction who order cakes, pizza and snacks by phone and pay with Orange Money. I designed the page mobile-first, with the menu and prices in Leones near the top and a WhatsApp and Call bar that stays on screen so a customer can order in one tap. To keep it fast on slow Salone networks, it is one HTML file with inline CSS, no JavaScript or frameworks, system fonts and compressed images that load lazily. I used 17px text, strong colour contrast, descriptive alt text and large tap targets so it is easy to use on a mid-range Android phone. The location uses a landmark and a Google Maps code, and the opening and delivery hours are clearly listed.
